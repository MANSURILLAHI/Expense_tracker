"""Expense Tracker - a command-line app to record and analyze personal expenses.

Run with:  python main.py
"""

import csv
from datetime import date

import database as db


# ---------- Input helpers (validation) ----------

def ask_amount(prompt="Amount (Rs): "):
    """Keep asking until the user enters a positive number."""
    while True:
        value = input(prompt).strip()
        try:
            amount = float(value)
            if amount <= 0:
                print("  Amount must be greater than zero.")
                continue
            return round(amount, 2)
        except ValueError:
            print("  Please enter a valid number, e.g. 250 or 99.50")


def ask_date(prompt="Date (YYYY-MM-DD, Enter for today): ", allow_blank=True):
    """Keep asking until the user enters a valid date."""
    while True:
        value = input(prompt).strip()
        if not value and allow_blank:
            return date.today().isoformat()
        if db.is_valid_date(value):
            return value
        print("  Invalid date. Use the format YYYY-MM-DD, e.g. 2025-01-31")


def ask_text(prompt, required=True):
    """Ask for text input; re-ask if it is required but empty."""
    while True:
        value = input(prompt).strip()
        if value or not required:
            return value
        print("  This field cannot be empty.")


def ask_id(prompt="Enter expense ID: "):
    """Ask for an integer ID."""
    while True:
        value = input(prompt).strip()
        if value.isdigit():
            return int(value)
        print("  Please enter a valid numeric ID.")


# ---------- Display helpers ----------

def print_expenses(rows):
    """Print expenses in a neat table."""
    if not rows:
        print("\n  No expenses found.\n")
        return

    print(f"\n{'ID':<5}{'Date':<13}{'Category':<16}{'Amount':>10}  Note")
    print("-" * 60)
    for r in rows:
        print(f"{r['id']:<5}{r['date']:<13}{r['category']:<16}{r['amount']:>10.2f}  {r['note']}")
    total = sum(r["amount"] for r in rows)
    print("-" * 60)
    print(f"{'Total':<34}{total:>10.2f}\n")


# ---------- Menu actions ----------

def add_expense():
    print("\n--- Add Expense ---")
    amount = ask_amount()
    category = ask_text("Category (e.g. Food, Travel, Rent): ")
    expense_date = ask_date()
    note = ask_text("Note (optional): ", required=False)
    new_id = db.add_expense(amount, category, expense_date, note)
    print(f"  Expense added successfully (ID {new_id}).\n")


def view_expenses():
    print("\n--- All Expenses ---")
    print_expenses(db.get_expenses())


def filter_expenses():
    print("\n--- Search / Filter (press Enter to skip a filter) ---")
    category = ask_text("Category: ", required=False)
    start = ask_date("From date (YYYY-MM-DD): ", allow_blank=False) if input("Filter by date range? (y/n): ").lower() == "y" else None
    end = ask_date("To date (YYYY-MM-DD): ", allow_blank=False) if start else None
    print_expenses(db.get_expenses(category or None, start, end))


def edit_expense():
    print("\n--- Edit Expense ---")
    expense_id = ask_id()
    current = db.get_expense_by_id(expense_id)
    if not current:
        print("  No expense found with that ID.\n")
        return

    print(f"  Editing: {current['date']} | {current['category']} | {current['amount']} | {current['note']}")
    print("  (Re-enter all values)")
    amount = ask_amount()
    category = ask_text("Category: ")
    expense_date = ask_date()
    note = ask_text("Note (optional): ", required=False)
    db.update_expense(expense_id, amount, category, expense_date, note)
    print("  Expense updated.\n")


def delete_expense():
    print("\n--- Delete Expense ---")
    expense_id = ask_id()
    if not db.get_expense_by_id(expense_id):
        print("  No expense found with that ID.\n")
        return
    confirm = input("  Are you sure? (y/n): ").strip().lower()
    if confirm == "y":
        db.delete_expense(expense_id)
        print("  Expense deleted.\n")
    else:
        print("  Cancelled.\n")


def show_summary():
    print("\n--- Spending Summary ---")
    categories = db.category_totals()
    if not categories:
        print("  No data yet.\n")
        return

    grand_total = sum(c["total"] for c in categories)
    print(f"\n{'Category':<16}{'Count':>7}{'Total':>12}{'Share':>9}")
    print("-" * 44)
    for c in categories:
        share = c["total"] / grand_total * 100
        print(f"{c['category']:<16}{c['count']:>7}{c['total']:>12.2f}{share:>8.1f}%")
    print("-" * 44)
    print(f"{'Total':<23}{grand_total:>12.2f}")

    print("\nMonthly totals:")
    for m in db.monthly_totals():
        print(f"  {m['month']}: {m['total']:.2f}")
    print()


def export_to_csv():
    rows = db.get_expenses()
    if not rows:
        print("\n  Nothing to export.\n")
        return
    filename = "expenses_export.csv"
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Date", "Category", "Amount", "Note"])
        for r in rows:
            writer.writerow([r["id"], r["date"], r["category"], r["amount"], r["note"]])
    print(f"\n  Exported {len(rows)} expenses to {filename}\n")


# ---------- Main loop ----------

MENU = """
========== EXPENSE TRACKER ==========
 1. Add expense
 2. View all expenses
 3. Search / filter expenses
 4. Edit expense
 5. Delete expense
 6. Spending summary
 7. Export to CSV
 0. Exit
=====================================
"""

ACTIONS = {
    "1": add_expense,
    "2": view_expenses,
    "3": filter_expenses,
    "4": edit_expense,
    "5": delete_expense,
    "6": show_summary,
    "7": export_to_csv,
}


def main():
    db.init_db()
    while True:
        print(MENU)
        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Goodbye!")
            break
        action = ACTIONS.get(choice)
        if action:
            action()
        else:
            print("  Invalid choice. Please pick a number from the menu.")


if __name__ == "__main__":
    main()
