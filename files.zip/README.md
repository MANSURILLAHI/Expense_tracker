# 💰 Expense Tracker (Python + SQLite)

A command-line application to record, search, and analyze personal expenses.
Built with Python and SQLite, with input validation and automated unit tests.

## 🎯 Problem It Solves
Most people don't know where their money goes each month. This tool lets a user log
every expense and instantly see **how much was spent per category and per month**.

## ✨ Features
- **Add** expenses with amount, category, date, and note
- **View** all expenses in a formatted table with totals
- **Search / filter** by category and date range
- **Edit** and **delete** expenses (with confirmation)
- **Spending summary**: totals, counts, and percentage share per category, plus monthly totals
- **Export to CSV** for use in Excel or Google Sheets
- **Input validation**: rejects invalid amounts, dates, and empty fields

## 🛠 Tech Stack
| Area | Technology |
|------|-----------|
| Language | Python 3 |
| Database | SQLite (`sqlite3` module) |
| Testing | `unittest` |
| Version control | Git & GitHub |

No external libraries needed.

## 🧱 Project Structure
```
expense-tracker/
├── main.py            # User interface (menu, input validation, display)
├── database.py        # All database operations (CRUD, aggregations)
├── test_database.py   # Unit tests for the database layer
├── .gitignore
└── README.md
```
The code is split into a **UI layer** and a **database layer**, so each part can be
changed or tested on its own.

## 🚀 How to Run
1. Install Python 3.8 or higher
2. Clone the repository
   ```bash
   git clone https://github.com/<your-username>/expense-tracker.git
   cd expense-tracker
   ```
3. Start the app
   ```bash
   python main.py
   ```

## 🧪 Run the Tests
```bash
python -m unittest -v
```
8 tests cover adding, filtering, updating, deleting, aggregation, and date validation.

## 📸 Sample Output
```
Category          Count       Total    Share
--------------------------------------------
Travel                1     1200.00    61.5%
Food                  2      750.00    38.5%
--------------------------------------------
Total                       1950.00

Monthly totals:
  2025-02: 300.00
  2025-01: 1650.00
```
> 📌 Add a real screenshot of your terminal here (see "Next steps" below).

## 💡 What I Learned
- Designing a relational database and writing SQL queries (`GROUP BY`, `SUM`, `WHERE`)
- Using **parameterized queries** to prevent SQL injection
- Separating application logic from data access
- Validating user input and handling errors gracefully
- Writing unit tests with temporary databases

## 🔮 Future Improvements
- Web version using Flask
- Charts using Matplotlib
- Monthly budget limits with alerts
- User login for multiple users

## 👤 Author
**Your Name** · [LinkedIn](https://linkedin.com/in/your-profile) · your.email@example.com
