"""Database layer for the Expense Tracker.

All SQL lives in this file so the rest of the app never touches the
database directly. This separation makes the code easier to test and maintain.
"""

import sqlite3
from datetime import datetime

DB_NAME = "expenses.db"


def get_connection(db_name=DB_NAME):
    """Open a connection to the SQLite database."""
    conn = sqlite3.connect(db_name)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_name=DB_NAME):
    """Create the expenses table if it does not exist."""
    with get_connection(db_name) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS expenses (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                amount   REAL    NOT NULL CHECK (amount > 0),
                category TEXT    NOT NULL,
                date     TEXT    NOT NULL,
                note     TEXT
            )
            """
        )


def add_expense(amount, category, date, note="", db_name=DB_NAME):
    """Insert a new expense and return its id."""
    with get_connection(db_name) as conn:
        cursor = conn.execute(
            "INSERT INTO expenses (amount, category, date, note) VALUES (?, ?, ?, ?)",
            (amount, category.strip().title(), date, note.strip()),
        )
        return cursor.lastrowid


def get_expenses(category=None, start_date=None, end_date=None, db_name=DB_NAME):
    """Return expenses, optionally filtered by category and/or date range."""
    query = "SELECT * FROM expenses WHERE 1=1"
    params = []

    if category:
        query += " AND category = ?"
        params.append(category.strip().title())
    if start_date:
        query += " AND date >= ?"
        params.append(start_date)
    if end_date:
        query += " AND date <= ?"
        params.append(end_date)

    query += " ORDER BY date DESC, id DESC"

    with get_connection(db_name) as conn:
        return conn.execute(query, params).fetchall()


def update_expense(expense_id, amount, category, date, note, db_name=DB_NAME):
    """Update an existing expense. Returns True if a row was changed."""
    with get_connection(db_name) as conn:
        cursor = conn.execute(
            "UPDATE expenses SET amount=?, category=?, date=?, note=? WHERE id=?",
            (amount, category.strip().title(), date, note.strip(), expense_id),
        )
        return cursor.rowcount > 0


def delete_expense(expense_id, db_name=DB_NAME):
    """Delete an expense. Returns True if a row was removed."""
    with get_connection(db_name) as conn:
        cursor = conn.execute("DELETE FROM expenses WHERE id=?", (expense_id,))
        return cursor.rowcount > 0


def get_expense_by_id(expense_id, db_name=DB_NAME):
    """Return a single expense or None."""
    with get_connection(db_name) as conn:
        return conn.execute(
            "SELECT * FROM expenses WHERE id=?", (expense_id,)
        ).fetchone()


def category_totals(db_name=DB_NAME):
    """Return total spending grouped by category, highest first."""
    with get_connection(db_name) as conn:
        return conn.execute(
            """
            SELECT category, SUM(amount) AS total, COUNT(*) AS count
            FROM expenses
            GROUP BY category
            ORDER BY total DESC
            """
        ).fetchall()


def monthly_totals(db_name=DB_NAME):
    """Return total spending grouped by month (YYYY-MM)."""
    with get_connection(db_name) as conn:
        return conn.execute(
            """
            SELECT substr(date, 1, 7) AS month, SUM(amount) AS total
            FROM expenses
            GROUP BY month
            ORDER BY month DESC
            """
        ).fetchall()


def is_valid_date(date_text):
    """Check that a string is a valid date in YYYY-MM-DD format."""
    try:
        datetime.strptime(date_text, "%Y-%m-%d")
        return True
    except ValueError:
        return False
