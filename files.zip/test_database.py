"""Unit tests for database.py. Run with:  python -m unittest -v"""

import os
import tempfile
import unittest

import database as db


class TestDatabase(unittest.TestCase):
    def setUp(self):
        # Use a fresh temporary database for every test
        fd, self.db_name = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        db.init_db(self.db_name)

    def tearDown(self):
        os.remove(self.db_name)

    def test_add_and_fetch(self):
        db.add_expense(250.0, "food", "2025-01-10", "Lunch", self.db_name)
        rows = db.get_expenses(db_name=self.db_name)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["category"], "Food")  # normalised to Title case
        self.assertEqual(rows[0]["amount"], 250.0)

    def test_filter_by_category(self):
        db.add_expense(100, "Food", "2025-01-10", "", self.db_name)
        db.add_expense(500, "Travel", "2025-01-11", "", self.db_name)
        rows = db.get_expenses(category="travel", db_name=self.db_name)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["category"], "Travel")

    def test_filter_by_date_range(self):
        db.add_expense(100, "Food", "2025-01-05", "", self.db_name)
        db.add_expense(200, "Food", "2025-02-05", "", self.db_name)
        rows = db.get_expenses(start_date="2025-02-01", end_date="2025-02-28", db_name=self.db_name)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["amount"], 200)

    def test_update_expense(self):
        eid = db.add_expense(100, "Food", "2025-01-10", "Old", self.db_name)
        self.assertTrue(db.update_expense(eid, 150, "Snacks", "2025-01-11", "New", self.db_name))
        row = db.get_expense_by_id(eid, self.db_name)
        self.assertEqual(row["amount"], 150)
        self.assertEqual(row["category"], "Snacks")

    def test_delete_expense(self):
        eid = db.add_expense(100, "Food", "2025-01-10", "", self.db_name)
        self.assertTrue(db.delete_expense(eid, self.db_name))
        self.assertIsNone(db.get_expense_by_id(eid, self.db_name))
        self.assertFalse(db.delete_expense(eid, self.db_name))  # already gone

    def test_category_totals(self):
        db.add_expense(100, "Food", "2025-01-10", "", self.db_name)
        db.add_expense(300, "Food", "2025-01-11", "", self.db_name)
        db.add_expense(50, "Travel", "2025-01-12", "", self.db_name)
        totals = {r["category"]: r["total"] for r in db.category_totals(self.db_name)}
        self.assertEqual(totals["Food"], 400)
        self.assertEqual(totals["Travel"], 50)

    def test_monthly_totals(self):
        db.add_expense(100, "Food", "2025-01-10", "", self.db_name)
        db.add_expense(200, "Food", "2025-02-10", "", self.db_name)
        months = {r["month"]: r["total"] for r in db.monthly_totals(self.db_name)}
        self.assertEqual(months["2025-01"], 100)
        self.assertEqual(months["2025-02"], 200)

    def test_date_validation(self):
        self.assertTrue(db.is_valid_date("2025-01-31"))
        self.assertFalse(db.is_valid_date("31-01-2025"))
        self.assertFalse(db.is_valid_date("2025-13-45"))


if __name__ == "__main__":
    unittest.main()
